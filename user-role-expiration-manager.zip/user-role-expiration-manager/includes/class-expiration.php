<?php
/**
 * Core Expiration Logic Engine.
 *
 * @package UserRoleExpirationManager
 */

namespace UserRoleExpirationManager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Expiration
 */
class Expiration {

	/**
	 * Meta key constants.
	 */
	public const META_ENABLED       = '_urem_expiration_enabled';
	public const META_START         = '_urem_expiration_start';
	public const META_DURATION      = '_urem_expiration_duration';
	public const META_UNIT          = '_urem_expiration_unit';
	public const META_ROLE          = '_urem_expiration_role';
	public const META_TIMESTAMP     = '_urem_expiration_ts';
	public const META_REMINDER_SENT = '_urem_reminder_sent';

	/**
	 * Check if a user is the Primary Administrator / Plugin Configurator / Site Owner.
	 *
	 * Primary configurator admins have permanent immunity from role expiration.
	 *
	 * @param int $user_id User ID.
	 * @return bool True if primary admin.
	 */
	public static function is_primary_admin( int $user_id ): bool {
		if ( 1 === $user_id ) {
			return true;
		}

		$settings   = Settings::get_settings();
		$primary_id = ! empty( $settings['primary_admin_id'] ) ? (int) $settings['primary_admin_id'] : 0;

		if ( $primary_id && $user_id === $primary_id ) {
			return true;
		}

		if ( is_user_logged_in() && get_current_user_id() === $user_id && current_user_can( 'manage_options' ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Get user expiration metadata with fallback to saved global settings options.
	 *
	 * @param int $user_id User ID.
	 * @return array Expiration data array.
	 */
	public static function get_user_expiration_data( int $user_id ): array {
		$enabled  = get_user_meta( $user_id, self::META_ENABLED, true );
		$start    = get_user_meta( $user_id, self::META_START, true );
		$duration = get_user_meta( $user_id, self::META_DURATION, true );
		$unit     = get_user_meta( $user_id, self::META_UNIT, true );
		$role     = get_user_meta( $user_id, self::META_ROLE, true );

		$settings = Settings::get_settings();

		// Primary admin accounts are disabled by default for absolute security
		if ( self::is_primary_admin( $user_id ) ) {
			$enabled = '0';
		}

		// Fallbacks to saved global settings options
		if ( '' === $enabled ) {
			$enabled = '0';
		}

		if ( empty( $start ) ) {
			$start = current_time( 'Y-m-d H:i:s' );
		}

		if ( '' === $duration || false === $duration ) {
			$duration = (int) $settings['default_duration'];
		} else {
			$duration = (int) $duration;
		}

		if ( empty( $unit ) ) {
			$unit = $settings['default_unit'];
		}

		if ( '' === $role || false === $role ) {
			$role = $settings['default_role'];
		}

		return array(
			'enabled'  => '1' === (string) $enabled,
			'start'    => $start,
			'duration' => $duration,
			'unit'     => $unit,
			'role'     => $role,
		);
	}

	/**
	 * Calculate exact expiration timestamp for a user.
	 *
	 * @param int $user_id User ID.
	 * @return int|null Timestamp or null if not set.
	 */
	public static function get_expiration_timestamp( int $user_id ): ?int {
		if ( self::is_primary_admin( $user_id ) ) {
			return null;
		}

		$data = self::get_user_expiration_data( $user_id );

		if ( ! $data['enabled'] || empty( $data['start'] ) || $data['duration'] <= 0 ) {
			return null;
		}

		$start_ts = is_numeric( $data['start'] ) ? (int) $data['start'] : strtotime( $data['start'] );
		if ( ! $start_ts ) {
			return null;
		}

		$modifier = '+' . $data['duration'] . ' ' . $data['unit'];
		return strtotime( $modifier, $start_ts );
	}

	/**
	 * Save/Update indexed timestamp user meta for fast SQL queries.
	 *
	 * @param int $user_id User ID.
	 * @return int|null Calculated timestamp.
	 */
	public static function update_expiration_timestamp_meta( int $user_id ): ?int {
		$ts = self::get_expiration_timestamp( $user_id );
		if ( null !== $ts ) {
			update_user_meta( $user_id, self::META_TIMESTAMP, $ts );
		} else {
			delete_user_meta( $user_id, self::META_TIMESTAMP );
		}

		// Reset reminder sent meta if start date changed
		delete_user_meta( $user_id, self::META_REMINDER_SENT );

		return $ts;
	}

	/**
	 * Get remaining days until expiration.
	 *
	 * @param int $user_id User ID.
	 * @return int|null Remaining days (negative if expired, null if disabled).
	 */
	public static function get_remaining_days( int $user_id ): ?int {
		if ( self::is_primary_admin( $user_id ) ) {
			return null;
		}

		$exp_ts = self::get_expiration_timestamp( $user_id );
		if ( null === $exp_ts ) {
			return null;
		}

		$now      = current_time( 'timestamp' );
		$diff_sec = $exp_ts - $now;

		return (int) floor( $diff_sec / DAY_IN_SECONDS );
	}

	/**
	 * Get user expiration status.
	 *
	 * @param int $user_id User ID.
	 * @return string 'active', 'expiring_soon', 'expired', or 'disabled'.
	 */
	public static function get_user_status( int $user_id ): string {
		if ( self::is_primary_admin( $user_id ) ) {
			return 'disabled';
		}

		$data = self::get_user_expiration_data( $user_id );
		if ( ! $data['enabled'] ) {
			return 'disabled';
		}

		$exp_ts = self::get_expiration_timestamp( $user_id );
		if ( null === $exp_ts ) {
			return 'disabled';
		}

		$now = current_time( 'timestamp' );

		if ( $now >= $exp_ts ) {
			return 'expired';
		}

		$days      = self::get_remaining_days( $user_id );
		$threshold = (int) apply_filters( 'urem_expiring_soon_threshold_days', 30 );

		if ( null !== $days && $days <= $threshold ) {
			return 'expiring_soon';
		}

		return 'active';
	}

	/**
	 * Check if a user is expired.
	 *
	 * @param int $user_id User ID.
	 * @return bool True if expired.
	 */
	public static function is_user_expired( int $user_id ): bool {
		return 'expired' === self::get_user_status( $user_id );
	}

	/**
	 * Check and send pre-expiration warning email reminders to users.
	 *
	 * @param int $user_id User ID.
	 * @return bool True if reminder sent.
	 */
	public static function check_and_send_pre_expiration_reminder( int $user_id ): bool {
		if ( self::is_primary_admin( $user_id ) ) {
			return false;
		}

		$settings = Settings::get_settings();
		if ( empty( $settings['send_reminder_email'] ) ) {
			return false;
		}

		$already_sent = get_user_meta( $user_id, self::META_REMINDER_SENT, true );
		if ( '1' === (string) $already_sent ) {
			return false;
		}

		$days_left     = self::get_remaining_days( $user_id );
		$reminder_days = (int) $settings['reminder_days_before'];

		if ( null === $days_left || $days_left < 0 || $days_left > $reminder_days ) {
			return false;
		}

		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return false;
		}

		$old_roles   = (array) $user->roles;
		$old_role    = ! empty( $old_roles ) ? reset( $old_roles ) : 'none';
		$target_role = get_user_meta( $user_id, self::META_ROLE, true );
		$exp_ts      = self::get_expiration_timestamp( $user_id );

		$placeholders = array(
			'{user_name}'       => $user->display_name,
			'{old_role}'        => $old_role,
			'{new_role}'        => $target_role,
			'{site_name}'       => get_bloginfo( 'name' ),
			'{expiration_date}' => urem_format_datetime( $exp_ts ),
			'{days_left}'       => (string) max( 0, $days_left ),
		);

		$subject = strtr( $settings['reminder_subject'], $placeholders );
		$message = strtr( $settings['reminder_message'], $placeholders );

		$sent = wp_mail( $user->user_email, $subject, $message, array( 'Content-Type: text/plain; charset=UTF-8' ) );

		if ( $sent ) {
			update_user_meta( $user_id, self::META_REMINDER_SENT, '1' );
			Logger::add_log( $user_id, $user->user_email, $old_role, $target_role, 'reminder_email', sprintf( __( 'Pre-expiration reminder email sent (%d days left).', 'user-role-expiration-manager' ), $days_left ) );
		}

		return $sent;
	}

	/**
	 * Execute role expiration transition for a user.
	 *
	 * Includes strict immunity guards to prevent Primary Administrator self-expiration.
	 *
	 * @param int    $user_id User ID.
	 * @param string $trigger Trigger source ('cron', 'manual_scan', 'manual_single', 'bulk_action').
	 * @return bool Success status.
	 */
	public static function process_user_expiration( int $user_id, string $trigger = 'cron' ): bool {
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return false;
		}

		// STRICT PRIMARY ADMIN IMMUNITY GUARD: Prevent Primary Admin / Configurator / Owner from being expired
		if ( self::is_primary_admin( $user_id ) ) {
			return false;
		}

		$data = self::get_user_expiration_data( $user_id );

		// Retrieve primary old role
		$old_roles   = (array) $user->roles;
		$old_role    = ! empty( $old_roles ) ? reset( $old_roles ) : 'none';
		$target_role = $data['role'];

		// Do not process if target role is identical to current role
		if ( $old_role === $target_role ) {
			return false;
		}

		// SAFETY GUARD 2: Filter hook allowing custom role exclusion
		$should_expire = apply_filters( 'urem_should_expire_user', true, $user_id, $old_role, $target_role, $trigger );
		if ( ! $should_expire ) {
			return false;
		}

		$settings = Settings::get_settings();
		$dry_run  = ! empty( $settings['dry_run_mode'] );

		/**
		 * Action before user role is updated by expiration manager.
		 *
		 * @param int    $user_id User ID.
		 * @param string $old_role Previous primary role.
		 * @param string $target_role Target primary role.
		 * @param string $trigger Trigger type.
		 */
		do_action( 'urem_before_user_expired', $user_id, $old_role, $target_role, $trigger );

		if ( ! $dry_run ) {
			if ( 'none' === $target_role || '' === $target_role ) {
				$user->set_role( '' );
			} else {
				$user->set_role( $target_role );
			}

			// Logout user session if enabled
			if ( ! empty( $settings['logout_user_on_expire'] ) ) {
				$sessions = \WP_Session_Tokens::get_instance( $user_id );
				$sessions->destroy_all();
			}

			// Send notification email if enabled
			if ( ! empty( $settings['send_email_on_expire'] ) ) {
				self::send_expiration_email( $user, $old_role, $target_role );
			}
		}

		// Record Log
		$reason = sprintf(
			/* translators: 1: Old role, 2: New role, 3: Trigger name, 4: Dry run tag */
			__( 'Role changed from %1$s to %2$s via %3$s%4$s.', 'user-role-expiration-manager' ),
			$old_role,
			$target_role,
			$trigger,
			$dry_run ? ' [DRY RUN]' : ''
		);

		Logger::add_log( $user_id, $user->user_email, $old_role, $target_role, $trigger, $reason );

		/**
		 * Action after user role is updated by expiration manager.
		 *
		 * @param int    $user_id User ID.
		 * @param string $old_role Previous primary role.
		 * @param string $target_role Target primary role.
		 * @param string $trigger Trigger type.
		 */
		do_action( 'urem_after_user_expired', $user_id, $old_role, $target_role, $trigger );

		return true;
	}

	/**
	 * Send email notification to user upon role expiration using template settings.
	 *
	 * @param \WP_User $user WP_User object.
	 * @param string   $old_role Previous role.
	 * @param string   $new_role New role.
	 * @return bool Mail send result.
	 */
	private static function send_expiration_email( \WP_User $user, string $old_role, string $new_role ): bool {
		$settings = Settings::get_settings();
		$exp_ts   = self::get_expiration_timestamp( $user->ID );

		$placeholders = array(
			'{user_name}'       => $user->display_name,
			'{old_role}'        => $old_role,
			'{new_role}'        => $new_role,
			'{site_name}'       => get_bloginfo( 'name' ),
			'{expiration_date}' => urem_format_datetime( $exp_ts ),
			'{days_left}'       => '0',
		);

		$subject = strtr( $settings['email_subject'], $placeholders );
		$message = strtr( $settings['email_message'], $placeholders );

		$headers = array( 'Content-Type: text/plain; charset=UTF-8' );

		return wp_mail( $user->user_email, $subject, $message, $headers );
	}
}
